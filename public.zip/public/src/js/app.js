// if ('serviceWorker' in navigator) {
//   navigator.serviceWorker.register('/sw.js')
//     .then(function() {
//       console.log('SW registered');
//     });
// }

// check for Servicworker
if ('serviceWorker' in navigator && 'PushManager' in window) {
  console.log('Service Worker and Push is supported');

  navigator.serviceWorker.register('/sw.js')
  .then(function(swReg) {
    console.log('Service Worker is registered', swReg);

    swRegistration = swReg;
    initializeUI();
  })
  .catch(function(error) {
    console.error('Service Worker Error', error);
  });
} else {
  console.warn('Push messaging is not supported');
  pushButton.textContent = 'Push Not Supported';
}

///////////// PUSH NOTIFICATIONS /////////////////////////
const applicationServerPublicKey = 'BIqju6gsCzRf4rH9PQeLRT06waE95h8KJUaYO9ioM3D6hwML59bM-DBadPS7zpYGN5Dy7KE36NHreoMhUvwVspM';
const applicationServerKey = urlB64ToUint8Array(applicationServerPublicKey);

const pushButton = document.querySelector('.js-push-btn');

let isSubscribed = false;
let swRegistration = null;

function urlB64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/\-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}


// Update the button
function updateBtn() {
  if (Notification.permission === 'denied') {
    pushButton.textContent = 'Push-meddelser Blokeret.';
    pushButton.disabled = true;
    updateSubscriptionOnServer(null);
    return;
  }

  if (isSubscribed) {
    pushButton.textContent = 'Frameld push-meddelser';
  } else {
    pushButton.textContent = 'Tilmeld push-meddelser';
  }

  pushButton.disabled = false;
}

// Print subscription / normally send to backend (sql)
function updateSubscriptionOnServer(subscription) {

  const subscriptionJson = document.querySelector('.js-subscription-json');

  if (subscription) {
    subscriptionJson.textContent = 'Tilmeldt';
  } else {
    subscriptionJson.textContent = 'Endnu ikke tilmeldt';
  }
}

// Subcribe function
function subscribeUser() {
  swRegistration.pushManager.subscribe({
    userVisibleOnly: true,
    applicationServerKey: applicationServerKey
  })
  .then(function(subscription) {
    console.log('User is subscribed.');

    updateSubscriptionOnServer(subscription);

    isSubscribed = true;

    updateBtn();
  })
  .catch(function(err) {
    console.log('Failed to subscribe the user: ', err);
    updateBtn();
  });
}

// Check user for push-member 
function initializeUI() {
  pushButton.addEventListener('click', function() {
    pushButton.disabled = true;
    if (isSubscribed) {
      unsubscribeUser();
    } else {
      subscribeUser();
    }
  });

  // Set the initial subscription value
  swRegistration.pushManager.getSubscription()
  .then(function(subscription) {
    isSubscribed = !(subscription === null);
 
    updateSubscriptionOnServer(subscription);

    if (isSubscribed) {
      console.log('User IS subscribed.');
    } else {
      console.log('User is NOT subscribed.');

    }

    updateBtn();
  });
}


// Unsubscribe user function
function unsubscribeUser() {
  swRegistration.pushManager.getSubscription()
  .then(function(subscription) {
    if (subscription) {
      return subscription.unsubscribe();
    }
  })
  .catch(function(error) {
    console.log('Error unsubscribing', error);
  })
  .then(function() {
    updateSubscriptionOnServer(null);

    console.log('User is unsubscribed.');
    isSubscribed = false;
    updateBtn();
  });
}

