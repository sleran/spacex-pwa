////////////////////// Hent fra API

const buildList = function (data) {
    const section = document.createElement('section');
    section.setAttribute('class', 'listBuilded');
  
    for (let i = 0; i < data.length; i++) {
      const article = document.createElement('article');
      article.setAttribute('class', 'card');
      

      const itemHead = document.createElement('div');
      itemHead.setAttribute('class', 'listItemHead');
      //itemHead.setAttribute('onclick', 'toggleElement()')
      

      const h2 = document.createElement('h2');
      h2.setAttribute('class', 'listItemName');
      const flightNumber = document.createTextNode(`Launch nr: ${data[i].flight_number} `);

      const rocket = document.createElement('i');
      rocket.setAttribute('class', 'fas fa-space-shuttle');
      const fire = document.createElement('i');
      fire.setAttribute('class', 'fire fas');
      const arrowUp = document.createElement('i');
      arrowUp.setAttribute('class', 'fas fa-chevron-circle-down'); 
  
      const info = document.createElement('div');
      info.setAttribute('class', 'info hideElement');
      const launchElement = document.createElement('p');
      launchElement.setAttribute('class', 'date');
      const launchDate = document.createTextNode(`Afsendes: ${data[i].launch_date_local} `);
  
      article.appendChild(itemHead);
      itemHead.appendChild(h2);
      h2.appendChild(arrowUp);
      h2.appendChild(flightNumber);
      h2.appendChild(fire);
      h2.appendChild(rocket);

      article.appendChild(info);
      launchElement.appendChild(launchDate)
      info.appendChild(launchElement);
      
      section.appendChild(article);
  }
    addSwipe(section);
    return section; 
  };
  
  const hentListe = function () {
    fetch(`https://api.spacexdata.com/v3/launches/upcoming`)
      .then(response => response.json())
      .then(data => { 
        document
            .querySelector('section')
            .appendChild(buildList(data));
    });
  
  };
    
  hentListe();


  