
function addSwipe(section){
    const launches = section.querySelectorAll('.card');
        
    for (let i = 0; i < launches.length; i++) { 
        var mc = new Hammer(launches[i]);
        const name = launches[i].querySelector('.listItemName').innerText;
        const message = document.querySelector('.message');

        mc.on("swipe", function() {
            message.innerHTML = `${name} er fjernet fra listen`;
            message.style.padding = '1em 2em';
            launches[i].classList.add('hideElement');
        });
    }


    const launchies = section.querySelectorAll('.listItemHead');

    launchies.forEach(launch => {
        
        launch.addEventListener('click', () => {
            const element = launch.nextElementSibling.classList;
            element.toggle("hideElement");

            const arrow = launch.querySelector('.fa-chevron-circle-down')
            if (arrow.classList.contains('fa-chevron-circle-down')) {
                arrow.classList.toggle('fa-chevron-circle-up')
            }
            
            const fire = launch.querySelector('.fire');
            fire.classList.toggle('fa-fire');
        })

    });
}