const CACHE_NAME = 'static-cache-v7';
const DATA_CACHE_NAME = 'data-cache-v6';

self.addEventListener('install', function (event) {
  console.log('SW Installed');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(function (cache) {
        cache.addAll([
          '/',
          '/index.html',
          '/favicon.ico',
          '/manifest.json',
          '/src/js/app.js',
          '/src/js/api.js',
          '/src/js/hammer.min.js',
          '/src/js/functions.js',
          '/src/css/app.css',
          '/src/images/icons/icon-128x128.png',
          'https://fonts.googleapis.com/css?family=Raleway:400,700',
          'https://api.spacexdata.com/v3/launches/upcoming'
        ]);
      })
  );
});

self.addEventListener('activate', function () {
  console.log('SW Activated');
});

self.addEventListener('fetch', function(event) {
  event.respondWith(
    caches.match(event.request)
      .then(function(res) {
        if (res) {
          return res;
        } else {
          return fetch(event.request);
        }
      })
  );
});

// Push message (build without backend)
self.addEventListener('push', function(event) {
  console.log('[Service Worker] Push Received.');
  console.log(`[Service Worker] Push had this data: "${event.data.text()}"`);

  const title = 'Så er der nyt fra SpaceX';
  const options = {
    body: 'Nye raketter i vente',
    icon: 'images/icons/icon-96x96.png',
    badge: 'images/icons/icon-72x72.png'
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

// Await click on notification
self.addEventListener('notificationclick', function(event) {
  console.log('[Service Worker] Notification click Received.');

  event.notification.close();

  event.waitUntil(
    clients.openWindow('https://developers.google.com/web/')
  );
});